import React, { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

function App() {
  const [origem, setOrigem] = useState('');
  const [destino, setDestino] = useState('');
  const [resultado, setResultado] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState('');
  const [semRota, setSemRota] = useState(false);
  const [mostrarInstrucoes, setMostrarInstrucoes] = useState(true);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErro('');
    setResultado(null);
    setSemRota(false);
    setMostrarInstrucoes(false);

    if (!origem || !destino) {
      setErro('Por favor, preencha ambos os campos.');
      return;
    }

    if (origem.toLowerCase() === destino.toLowerCase()) {
      setErro('A cidade de origem e destino não podem ser iguais.');
      return;
    }

    setCarregando(true);

    try {
      const response = await axios.post('http://localhost:8000/caminho', {
        origem,
        destino,
      });

      if (response.data?.caminho?.length > 0) {
        setResultado(response.data);
      } else {
        setSemRota(true);
      }
    } catch (error) {
      setErro('Erro ao calcular o caminho. Verifique os nomes das cidades e tente novamente.');
    } finally {
      setCarregando(false);
    }
  };

  const handleLimpar = () => {
    setOrigem('');
    setDestino('');
    setResultado(null);
    setErro('');
    setSemRota(false);
    setMostrarInstrucoes(true);
  };

  return (
    <div className="app-container">
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-10 col-lg-8">
            <div className="card main-card">
              <div className="card-header">
                <h1 className="text-center mb-0 app-title">
                  <FontAwesomeIcon icon="route" className="me-3" /> Calculadora de Rotas
                </h1>
              </div>
              <div className="card-body">
                {mostrarInstrucoes && (
                  <div className="alert alert-info alert-instrucoes">
                    <p>
                      <FontAwesomeIcon icon="info-circle" className="me-2" />
                      Digite as cidades de origem e destino para encontrar a melhor rota.
                    </p>
                  </div>
                )}

                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label-custom" htmlFor="origem">
                      Origem
                    </label>
                    <input
                      type="text"
                      id="origem"
                      aria-label="Cidade de origem"
                      aria-required="true"
                      className="form-control form-control-custom"
                      value={origem}
                      onChange={(e) => setOrigem(e.target.value)}
                      placeholder="Nome da cidade de origem"
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label-custom" htmlFor="destino">
                      Destino
                    </label>
                    <input
                      type="text"
                      id="destino"
                      aria-label="Cidade de destino"
                      aria-required="true"
                      className="form-control form-control-custom"
                      value={destino}
                      onChange={(e) => setDestino(e.target.value)}
                      placeholder="Nome da cidade de destino"
                    />
                  </div>

                  <div className="button-container">
                    <button type="submit" className="btn-custom">
                      {carregando ? (
                        <FontAwesomeIcon icon="spinner" spin />
                      ) : (
                        'Calcular Rota'
                      )}
                    </button>
                    <button type="button" className="btn-limpar" onClick={handleLimpar}>
                      Limpar
                    </button>
                  </div>
                </form>

                {erro && (
                  <div className="alert alert-danger mt-3" role="alert" aria-live="assertive">
                    {erro}
                  </div>
                )}

                {semRota && (
                  <div className="alert alert-warning mt-3" role="alert" aria-live="assertive">
                    Não foi possível encontrar uma rota entre as cidades fornecidas.
                  </div>
                )}
              </div>
            </div>
            {resultado && (
              <div className="result-card mt-4">
                <div className="result-header">
                  <h2 className="result-title">Caminho Encontrado</h2>
                </div>
                <ul className="list-group">
                  {resultado.caminho.map((cidade, index) => (
                    <li
                      className="list-group-item d-flex justify-content-between align-items-start list-group-item-custom"
                      key={index}
                    >
                      <div className="ms-2 me-auto">
                        <div className="city-name">
                          <span className="city-index">{index + 1}.</span>
                          {cidade}
                        </div>
                      </div>
                      {index < resultado.distancias_percorridas.length && (
                        <span className="badge bg-primary rounded-pill badge-custom">
                          {resultado.distancias_percorridas[index][2]} km
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
                <div className="total-distance mt-4">
                  <h4>Distância Total:</h4>
                  <div className="distance-value">{resultado.distancia_total} km</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
