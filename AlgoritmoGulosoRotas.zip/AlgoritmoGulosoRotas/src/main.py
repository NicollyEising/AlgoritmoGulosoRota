from fastapi import FastAPI, Response, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any
import logging
import json
from functools import lru_cache

# Configuração do logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuração do FastAPI
app = FastAPI()

# Configuração do CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rota de status
@app.options("/caminho")
async def options_caminho():
    return Response(status_code=200)

# Cache de cidades
CIDADES_CACHE: Dict[str, Dict[str, Any]] = {}

# Carregar cidades a partir do arquivo JSON
@app.on_event("startup")
def carregar_cidades():
    global CIDADES_CACHE
    cidades = {}
    try:
        with open(r"C:\Users\faculdade\Desktop\muita tralha\algoritmo guloso\AlgoritmoGulosoRotas\data\cidades.json", "r", encoding="utf-8") as file:
            data = json.load(file)
            for cidade_nome, conexoes in data.items():
                # Normalizando os nomes das cidades e conexões para minúsculo
                cidade_nome_norm = cidade_nome.lower()
                conexoes_norm = {k.lower(): v for k, v in conexoes.items()}
                cidades[cidade_nome_norm] = conexoes_norm
        CIDADES_CACHE = cidades
        logger.info("Cidades carregadas e cacheadas.")
    except FileNotFoundError:
        logger.error("O arquivo 'data/cidades.json' não foi encontrado.")
    except json.JSONDecodeError:
        logger.error("Erro ao decodificar o arquivo JSON.")
    except Exception as e:
        logger.error(f"Ocorreu um erro ao carregar as cidades: {e}")

# Algoritmo guloso
def caminho_guloso(origem: str, destino: str) -> Dict[str, Any]:
    origem_norm = origem.lower()
    destino_norm = destino.lower()
    cidades = CIDADES_CACHE

    if origem_norm == destino_norm:
        return {"erro": "A cidade de origem e destino não podem ser iguais."}
    if origem_norm not in cidades:
        return {"erro": f"Cidade de origem '{origem}' não encontrada."}

    caminho = [origem_norm]
    distancias_percorridas = []
    cidade_atual = origem_norm
    visitadas = {origem_norm}
    pilha = []

    while cidade_atual != destino_norm:
        if cidade_atual not in cidades:
            return {"erro": f"Cidade '{cidade_atual}' não encontrada no banco de dados."}
        vizinhos = cidades[cidade_atual]
        vizinhos_filtrados = {c: d for c, d in vizinhos.items() if c not in visitadas and c in cidades}
        if not vizinhos_filtrados:
            if pilha:
                ultima_cidade, _ = pilha.pop()
                caminho.pop()
                if distancias_percorridas:
                    distancias_percorridas.pop()
                cidade_atual = ultima_cidade
                continue
            else:
                return {"erro": f"Não há caminho disponível de '{origem}' para '{destino}'."}
        proxima_cidade = min(vizinhos_filtrados, key=vizinhos_filtrados.get)
        distancia = vizinhos_filtrados[proxima_cidade]

        caminho.append(proxima_cidade)
        distancias_percorridas.append((cidade_atual, proxima_cidade, distancia))
        pilha.append((cidade_atual, distancia))
        cidade_atual = proxima_cidade
        visitadas.add(proxima_cidade)
    
    distancia_total = sum(d for _, _, d in distancias_percorridas)
    return {"caminho": caminho, "distancias_percorridas": distancias_percorridas, "distancia_total": distancia_total}

class Requisicao(BaseModel):
    origem: str
    destino: str

@app.post("/caminho")
async def calcular_caminho(requisicao: Requisicao):
    resultado = caminho_guloso(requisicao.origem, requisicao.destino)
    if "erro" in resultado:
        raise HTTPException(status_code=400, detail=resultado["erro"])
    return resultado

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)